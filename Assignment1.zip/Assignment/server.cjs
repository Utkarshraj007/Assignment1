const http = require('http');
const url = require('url');
const fs= require('fs');
const querystring = require('querystring');
const getData = require("./script.cjs");
const server = http.createServer(async(req, res) => {
  
  const urlparse = url.parse(req.url, true);
  
  if(urlparse.pathname == '/gettimestories' && req.method == 'GET')
  {
    await getData(res);
  }
  
});

server.listen(8080,"localhost");
