const axios = require("axios")
module.exports = async (response) => {
    axios('https://time.com/')
    .then(res =>{
        const htmlData = res.data
    
        const ptrn="tout__list-item-title"
    
        const headTag="</h3>"
    
       const headList =htmlData.split(ptrn);
       
        let titleList=[]
    
        for(let i=1;i<headList.length;i+=2)                                                                             
        {
         const title=headList[i].split(headTag)
    
         titleList.push(title[0].replaceAll('">',""))
       }
    
       const linkPtrn='tout__list-item-link" href="/'
    
       const linkList=htmlData.split(linkPtrn)
       const linkTag='/"'
    
        let titleLinkList=[]
    
        for(let i=1;i<headList.length;i+=2)
        {
         const title=linkList[i].split(linkPtrn)
    
         const linkAncchor=title[0].split(linkTag);
         titleLinkList.push(linkAncchor[0])
        }
    
        let resList=[]
    
        for(let i=0;i<5;i++)
        {
            resList.push({
                title:titleList[i],
                link:"https://time.com/"+titleLinkList[i]
            })
        }
    
      //  console.log(resList)
        response.writeHead(200, {'Content-Type': 'application/json'});
        response.end(JSON.stringify(resList, null, 2));
    
    }).catch(err => console.log(err))
}